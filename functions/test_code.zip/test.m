load sglfitF_data

sgl(x,y);